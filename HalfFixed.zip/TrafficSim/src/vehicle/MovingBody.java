package vehicle;

public interface MovingBody {
    int getPositionX();
    int getPositionY();
    int getCurVel();
}
