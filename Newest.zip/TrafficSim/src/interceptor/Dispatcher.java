package interceptor;

import java.io.File;
import java.io.FileNotFoundException;
import java.io.PrintWriter;
import java.util.Scanner;
import java.text.SimpleDateFormat;
import java.util.Calendar;
import javax.swing.JOptionPane;

/**
 * @author Graham
 * manages interceptors
 */

public class Dispatcher implements Interceptor
{
    static String info;
    static String min;
    
    public static void log(int fileNumber)
    {
        //register crash
        String time = new SimpleDateFormat("yyyyMMdd_HHmmss").format(Calendar.getInstance().getTime()); 
        //taken from http://stackoverflow.com/questions/5175728/how-to-get-the-current-date-time-in-java

        info= "Crash logged at/ ";
        info += time.substring(9,11);
        info += ":";
        info += time.substring(11,13);
        min = time.substring(11,13);
        
        Dispatcher myDispatcher = new Dispatcher();
        myDispatcher.registerCrash(fileNumber);
    }

    @Override
    public void registerCrash(int fileNumber) 
    {
        File sim = new File ("CrashLog"+fileNumber+".txt");
	Scanner in;
        String line="";
        try 
        {
            in = new Scanner(sim);
	    while(in.hasNext())
            {
                    line += (in.nextLine()+"\n");
            }
            
            PrintWriter pw = new PrintWriter(sim); //writes to
            if(line.contains(min))
            {
                pw.println(line);
            }
            else
            {
                pw.println(line);
                pw.println(info);
            }  
            in.close();
            pw.close();
            
        } 
        catch (FileNotFoundException ex) 
        {
            JOptionPane.showMessageDialog(null, "Encountered Error!", "Error", 2);
        }
	
    }
    
    //not used but included to allow for expansion and adaptibility 
    @Override
    public void remove(int fileNumber)
    {
        int count=0, track=0;
        File sim = new File ("CrashLog"+fileNumber+".txt");
	Scanner in;
        try 
        {
            in = new Scanner(sim);String line="";
            PrintWriter pw = new PrintWriter(sim); //writes to
	    if(in.hasNext())
            {
                count++; 
            }
            while(count>track+1)
            {
                line = in.nextLine();
                pw.println(line);
            }
            in.close();
            pw.close();
        } 
        catch (FileNotFoundException ex) 
        {
            JOptionPane.showMessageDialog(null, "Encountered Error!", "Error", 2);
        }
    }
}
