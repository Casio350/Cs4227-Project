package road;
import javax.swing.JOptionPane;
import trafficsim.TrafficSim;


public class NullRoad extends Road {
    
    private boolean isEntry;
    
    
     public NullRoad()
    {  
    }
    
    public boolean isLaneEntry(){ return isEntry; }
    
    public NullRoad(boolean isEntry, int x, int y, int id, boolean LTR){
        super(x,y,id, LTR);
        this.isEntry=isEntry;
    }
    
        
    public void instantiateRoad(int x, int y, int id, boolean LTR)
    {
        super.instantiateRoad(x,y,id,LTR);
    }
    
    public static void show ()
    {
        JOptionPane.showMessageDialog (null, "No road selected");
        
    }
    
    @Override
    public int getY(){  //the y position is different if not left to right        
        if(super.getLTR()) return super.getY();
        return super.getY()+((getLaneCount()-1)*TrafficSim.RoadHeight);
    }
     
    }
