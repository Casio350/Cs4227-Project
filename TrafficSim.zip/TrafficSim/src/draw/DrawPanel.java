package draw;

import java.awt.Graphics;
import java.awt.image.BufferedImage;
import java.io.File;
import java.util.ArrayList;
import javax.imageio.ImageIO;
import javax.swing.JPanel;
import trafficsim.TrafficSim;




public class DrawPanel extends JPanel
    {
    private BufferedImage carImg, reverseCarImg, roadImg;
    
    public DrawPanel(){ 
        //initalise images
        File carFile = new File("Images/car.png");
        File reverseCarFile = new File("Images/carFlipped.png");
        File roadFile = new File("Images/road.png");
        
        if(carFile.exists() && roadFile.exists() && reverseCarFile.exists()){
        try{
        carImg = ImageIO.read(carFile);
        roadImg = ImageIO.read(roadFile);
        reverseCarImg = ImageIO.read(reverseCarFile);
        }
        catch(Exception e){ e.printStackTrace(); }
        }
        else{
            System.out.print("File not found");
        }
    
    }

        @Override
        public void paintComponent(Graphics g)
        { 
            ArrayList<RoadView> RoadViews = TrafficSim.getRoadViews();
            
            for(RoadView r : RoadViews) //draw each road
                if(r.getType()==0){ //type is motorway
                    g.drawImage(roadImg,r.getX(),r.getY(), r.getW(), r.getH(), null);
                }
            
            
            ArrayList<VehicleView> vehViews = TrafficSim.getVehicleViews();
            BufferedImage img=carImg;
            boolean ImageIsLTR=true;
                    for(VehicleView v : vehViews){ //draw each vehicle
                        //change image depending on Left To Right (LTR)
                        if(v.getLTR() && !ImageIsLTR){
                            img=carImg;
                            ImageIsLTR=true;
                        }
                        
                        if(v.getLTR()==false && ImageIsLTR){
                            img=reverseCarImg;
                            ImageIsLTR=false;
                        }
                        
                        g.drawImage(img,v.posX(), v.posY(), 
                                TrafficSim.CarWidth, TrafficSim.CarHeight,null);
                        
                    }
                        
        }
    }
