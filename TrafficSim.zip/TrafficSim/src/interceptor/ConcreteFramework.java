
package interceptor;

import java.io.File;
import java.io.FileWriter;
import java.io.IOException;
import java.io.PrintWriter;
import javax.swing.JOptionPane;

/**
 * @author Graham
 * where everything happens
 */
public class ConcreteFramework
{
    static int fileNumber;
    
    public static void createDispatcher()
    {
        Dispatcher.log(fileNumber);
    }
    
    public static void newSimulation()
    {
        fileNumber=1;
        File sim = new File("CrashLog"+fileNumber+".txt");
	while (sim.exists())
	{
            fileNumber++;
            sim = new File("CrashLog"+fileNumber+".txt");
        }
        try 
        {
            //creates the new file
            FileWriter aFile = new FileWriter("CrashLog"+fileNumber+".txt");
            PrintWriter out = new PrintWriter(aFile);
            aFile.close();
            out.close();
        } 
        catch (IOException ex) 
        {
            JOptionPane.showMessageDialog(null, "Encountered Error!", "Error", 2);
        }
    }
}
