
package interceptor;

/**
 * @author Graham
 */

public class ContextObject
{
    String name; int x, y;
    
    public void setX(int num){x=num;}
    public void setY(int num){y=num;}
    public int getX(){return x;}
    public int getY(){return y;}
    public String getObjName(){return name;}
    public void setObjName(String setName){name=setName;}
}
