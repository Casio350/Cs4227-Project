
package interceptor;

/**
 * @author Graham
 * integrating out-of-band services
 */
public interface Interceptor
{
    public void registerCrash(int num);
    public void remove(int num);
}
