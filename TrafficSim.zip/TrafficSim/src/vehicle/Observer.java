
package vehicle;

public interface Observer { //viechle
    public void update();
}
